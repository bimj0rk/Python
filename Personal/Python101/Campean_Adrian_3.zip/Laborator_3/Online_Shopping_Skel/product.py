class Product:
    def __init__(self, name, price):
        self.name = name
        self.price = price

    def __add__(self, other):
        sum = self.price + other.price
        return sum
    
    def return_price(self):
        return self.price